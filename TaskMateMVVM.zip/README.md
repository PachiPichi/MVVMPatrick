# TaskMate — ejercicio MVVM (Kotlin + XML)

Incluye dos interfaces XML:
- `res/layout/activity_main.xml`: portrait.
- `res/layout-land/activity_main.xml`: landscape. Android selecciona automáticamente el layout según la orientación.
- Cuatro filas fijas, sin lógica para añadir ni borrar tareas.
- `TaskViewModel`: mantiene el estado de los checkboxes y los contadores de navegación.

## Comportamiento
1. **Todas**: si las cuatro tareas están marcadas, las desmarca; si no, las marca todas.
2. **Inicio / Tareas / Estadísticas / Perfil**: al pulsar un botón, los cuatro textos de tarea pasan a mostrar el nombre del botón pulsado.
3. Cada botón tiene su contador independiente. Por ejemplo, pulsar Inicio dos veces deja las cuatro etiquetas como `Inicio 2`; pulsar Perfil una vez después las deja como `Perfil 1`.

## Cómo integrarlo
Copia la carpeta `app/src/main` dentro del módulo `app` de un proyecto Android Studio Kotlin con AppCompat, Activity KTX y Lifecycle ViewModel/LiveData.

Dependencias necesarias en `app/build.gradle` (Groovy):
```gradle
dependencies {
    implementation "androidx.appcompat:appcompat:1.7.0"
    implementation "androidx.activity:activity-ktx:1.10.1"
    implementation "androidx.lifecycle:lifecycle-viewmodel-ktx:2.9.2"
    implementation "androidx.lifecycle:lifecycle-livedata-ktx:2.9.2"
}
```

El tema de la aplicación debe ser un tema AppCompat (por ejemplo `Theme.AppCompat.Light.NoActionBar`). Si tu proyecto usa otro paquete, cambia `package com.example.taskmate` y la ruta del directorio Kotlin para que coincidan.
