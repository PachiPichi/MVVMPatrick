package com.example.taskmate

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer

class MainActivity : AppCompatActivity() {
    private val viewModel: TaskViewModel by viewModels()

    private lateinit var allButton: Button
    private lateinit var checkBoxes: List<CheckBox>
    private lateinit var taskTexts: List<TextView>
    private lateinit var navButtons: List<Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        allButton = findViewById(R.id.btnTodas)
        checkBoxes = listOf(
            findViewById(R.id.checkTask1),
            findViewById(R.id.checkTask2),
            findViewById(R.id.checkTask3),
            findViewById(R.id.checkTask4)
        )
        taskTexts = listOf(
            findViewById(R.id.taskText1),
            findViewById(R.id.taskText2),
            findViewById(R.id.taskText3),
            findViewById(R.id.taskText4)
        )
        navButtons = listOf(
            findViewById(R.id.btnInicio),
            findViewById(R.id.btnTareas),
            findViewById(R.id.btnEstadisticas),
            findViewById(R.id.btnPerfil)
        )

        // El ViewModel mantiene el estado; el observador actualiza la interfaz.
        viewModel.checkedTasks.observe(this, Observer { states ->
            checkBoxes.forEachIndexed { index, checkBox ->
                if (checkBox.isChecked != states[index]) {
                    checkBox.isChecked = states[index]
                }
            }
        })

        viewModel.taskLabels.observe(this, Observer { labels ->
            taskTexts.forEachIndexed { index, textView ->
                textView.text = labels[index]
            }
        })

        checkBoxes.forEachIndexed { index, checkBox ->
            checkBox.setOnCheckedChangeListener { _, isChecked ->
                viewModel.setTaskChecked(index, isChecked)
            }
        }

        allButton.setOnClickListener {
            viewModel.toggleAllTasks()
        }

        navButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                viewModel.onNavigationClicked(index)
            }
        }
    }
}
