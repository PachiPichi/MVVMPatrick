package com.example.taskmate

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TaskViewModel : ViewModel() {
    private val initialTaskNames = listOf(
        "Estudiar Android XML",
        "Hacer ejercicio",
        "Leer un libro",
        "Preparar la presentación"
    )

    private val _checkedTasks = MutableLiveData(List(4) { false })
    val checkedTasks: LiveData<List<Boolean>> = _checkedTasks

    private val _taskLabels = MutableLiveData(initialTaskNames)
    val taskLabels: LiveData<List<String>> = _taskLabels

    // Contador independiente para Inicio, Tareas, Estadísticas y Perfil.
    private val navigationClicks = mutableListOf(0, 0, 0, 0)
    private val navigationNames = listOf("Inicio", "Tareas", "Estadísticas", "Perfil")

    fun setTaskChecked(index: Int, checked: Boolean) {
        val updated = _checkedTasks.value.orEmpty().toMutableList()
        if (index in updated.indices) {
            updated[index] = checked
            _checkedTasks.value = updated
        }
    }

    fun toggleAllTasks() {
        val current = _checkedTasks.value.orEmpty()
        // Si todas están marcadas, desmarca todas; en cualquier otro caso, márcalas.
        val newValue = !current.all { it }
        _checkedTasks.value = List(4) { newValue }
    }

    fun onNavigationClicked(index: Int) {
        if (index !in navigationNames.indices) return
        navigationClicks[index]++
        val label = "${navigationNames[index]} ${navigationClicks[index]}"
        _taskLabels.value = List(4) { label }
    }
}
